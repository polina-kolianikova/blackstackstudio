/* =========================================================
   BlackStack Studio — основной скрипт
   Лоадер, i18n, скролл-анимации, тилт, magnetic, печатная машинка
   ========================================================= */

/* =========================================================
   ПЕРЕВОДЫ (RU / EN / UK)
   ========================================================= */
const I18N = {
    ru: {
        "loader.label": "ИНИЦИАЛИЗАЦИЯ СИСТЕМЫ BLACKSTACK",

        "nav.expertise": "Практика",
        "nav.projects": "Кейсы",
        "nav.team": "Операторы",
        "nav.contact": "Бриф",
        "nav.cta": "Запустить проект",

        "hero.typed": "Цифровые продукты, которые работают на масштаб — пока конкуренты пишут ТЗ.",
        "hero.meta1": "Операторов",
        "hero.meta2": "Запусков",
        "hero.meta3": "На рынке с",
        "hero.scroll": "Дальше",

        "now.label": "NOW · СТУДИЯ В РАБОТЕ",
        "now.c1": "Активных спринтов",
        "now.c2": "В discovery",
        "now.c3": "На поддержке",
        "now.c4": "Операторов онлайн",
        "now.c5": "Ответ на бриф",
        "now.c6": "Слотов в Q3",

        "clients.label": "В хорошей компании",
        "clients.title": "Кейсы и партнёры",
        "clients.note": "Прямые запуски и white-label · NDA-проекты по запросу",

        "manifesto.num": "— / Манифест",
        "manifesto.quote": "Меньше встреч. Больше продакшена.",
        "manifesto.lead": "Вам не нужны 40-страничные брифы, weekly check-in'ы и презентации, продающие то, что вы уже купили. Вам нужен работающий продукт. Решения — за час. Релиз — через 30 дней. Доступ к коду — с первого коммита. Никаких прослоек.",
        "manifesto.sign": "BlackStack Studio · Манифест",

        "expertise.num": "01 / Практика",
        "expertise.title": "Что мы строим",
        "expertise.lead": "Мы делаем продукты, которые приносят деньги во сне. Пока вы спите — бот закрывает сделки, дашборд считает позицию, очередь чистится сама. Контроль. Скорость. Масштаб.",

        "card1.title": "Веб-продукты",
        "card1.text":  "React, Next.js, Node. Не сайты — машины конверсии: <1с LCP, измеримая воронка, продакшен за 4–8 недель. Каждый пиксель работает на доход.",
        "card2.title": "Автоматизация",
        "card2.text":  "Python, aiogram, PostgreSQL. Боты и пайплайны, которые заменяют отдел из пяти человек и не уходят в отпуск. Считаем экономию в часах и в зарплатах.",
        "card3.title": "Интерфейсы",
        "card3.text":  "Figma + код. Дизайн-системы, которые масштабируются с продуктом, а не разваливаются на третьей итерации. Эмоция, потом метрика — обе попадают в KPI.",
        "card3.tag2":  "Motion",
        "card3.tag3":  "Системы",
        "card4.title": "Кастом",
        "card4.text":  "Когда на рынке нет готового — мы это собираем. Архитектура под нагрузку, интеграции, MVP за 30 дней. Невозможное — это просто дороже.",
        "card4.tag1":  "Архитектура",

        "projects.num":  "02 / Кейсы",
        "projects.title":"Свежие запуски",
        "projects.lead": "Не портфолио — счётчик. Каждый проект приносит заказчику деньги или экономит их в часах. Доказательства внутри.",
        "projects.view": "Открыть кейс →",
        "proj1.tag":  "Финтех · Дашборд",
        "proj1.desc": "Торговый терминал реального времени: тики <80мс, командная палитра, собственный движок графиков. Заказчик ушёл с TradingView на наш стек за квартал.",
        "proj2.tag":  "SaaS · Автоматизация",
        "proj2.desc": "Внутренняя ОС, заменившая 14 SaaS-подписок. Окупилась за два месяца. Команда из 22 человек работает как 40.",
        "proj3.tag":  "Бренд · Веб",
        "proj3.desc": "Айдентика и микросайт для архитектурного бюро. Полгода — три попадания в подборки и очередь клиентов на полгода вперёд.",
        "proj4.tag":  "Бот · Telegram",
        "proj4.desc": "Многотенантный бот: 40 000 активных, stateful-флоу, биллинг, админка. Поддержка — один разработчик на четверть ставки.",

        "stats.num":   "02.5 / По цифрам",
        "stats.title": "Сложный процент в действии",
        "stats.lead":  "Цифры обновляются раз в месяц. Без округлений до миллиардов и без сказок.",
        "stats.c1":    "Проектов в продакшене",
        "stats.c2":    "Стран аудитории",
        "stats.c3":    "Релизов без отката",
        "stats.c4":    "Средняя скорость сайтов",
        "stats.c5":    "Пользователей у клиентов",
        "stats.c6":    "Поддержки после релиза",

        "process.num":   "03 / Процесс",
        "process.title": "Как мы работаем",
        "process.lead":  "Три фазы. Без сюрпризов. Без молчания на две недели. Без «мы вам напишем».",
        "process.s1.phase": "Discover",
        "process.s1.title": "Слушаем и режем лишнее",
        "process.s1.text":  "1–2 недели. Один созвон, технический аудит, прототип решения на бумаге. Уходим, если задача не наша.",
        "process.s1.time":  "1–2 недели",
        "process.s2.phase": "Build",
        "process.s2.title": "Строим в свет",
        "process.s2.text":  "4–10 недель. Релизы каждые 7 дней, общий канал в Telegram, доступ к репозиторию с первого дня.",
        "process.s2.time":  "4–10 недель",
        "process.s3.phase": "Compound",
        "process.s3.title": "Остаёмся и наращиваем",
        "process.s3.text":  "После релиза мы не исчезаем. Метрики, итерации, рост. Process > Event — мы здесь надолго.",
        "process.s3.time":  "60+ дней",
        "process.sign":  "«Сдал и забыл» — это event-логика. Мы — не такие.",

        "team.num":   "04 / Операторы",
        "team.title": "Четверо. Без посредников.",
        "team.lead":  "Ни менеджеров, ни прослойки. Вы пишете тем, кто пишет код. Решения — за час, а не за неделю созвонов.",
        "m1.name": "К. Воробьёв", "m1.role": "Бэкенд · Автоматизация",
        "m2.name": "А. Лернер",   "m2.role": "Бэкенд · Инфраструктура",
        "m3.name": "М. Соколова", "m3.role": "Фронтенд · Интерфейс",
        "m4.name": "Д. Рейзен",   "m4.role": "Дизайн · Арт-дирекшн",

        "engagement.num":   "05 / Модель работы",
        "engagement.title": "Как с нами работать",
        "engagement.lead":  "Никаких часовых ставок. Часы — это slowlane. Платим за результат, считаем по deliverables.",
        "engagement.e1.title": "Fixed Sprint",
        "engagement.e1.price": "от €18 000",
        "engagement.e1.text":  "30 дней, фиксированный scope, фиксированная цена. Для MVP и продуктовых ставок.",
        "engagement.e2.title": "Retainer",
        "engagement.e2.price": "от €12 000 / мес",
        "engagement.e2.text":  "Месячный контракт. Команда от одного оператора до четырёх. Для тех, кто строит, а не ремонтирует.",
        "engagement.e3.title": "Equity / Co-build",
        "engagement.e3.price": "доля + lower cash",
        "engagement.e3.text":  "Берём за технику долю. Для редких проектов, где видим Scale в чистом виде.",
        "engagement.e4.title": "Advisory",
        "engagement.e4.price": "€280 / час",
        "engagement.e4.text":  "Архитектурный аудит, code review, найм-консалтинг. Для founders, у которых уже есть команда.",

        "faq.num":   "06 / FAQ",
        "faq.title": "Главные страхи и наши ответы",
        "faq.lead":  "То, о чём вы спросите на третьей минуте созвона. Отвечаем заранее.",
        "faq.q1": "Сколько это стоит?",
        "faq.a1": "Sprint — от €18K фикс. Retainer — от €12K/мес. Точная цифра — после 30-минутного брифа. Никаких «давайте сначала договор подпишем».",
        "faq.q2": "За сколько вы делаете?",
        "faq.a2": "От 30 дней до продакшена для MVP. 4–10 недель для продуктов средней сложности. Дата релиза фиксируется в первом созвоне.",
        "faq.q3": "А если результат не понравится?",
        "faq.a3": "Релизы каждые 7 дней — вы видите всё на ходу. Не нравится — корректируем тогда же, не через месяц. Возврата не предусматриваем — только итерация.",
        "faq.q4": "Вас всего четверо — потянете большой проект?",
        "faq.a4": "Да. Каждый из нас закрывает свою зону end-to-end, без передач через менеджера. Один senior > пять джунов и трёх менеджеров. Если не тянем — говорим до брифа, не на второй неделе.",
        "faq.q5": "Берёте срочно?",
        "faq.a5": "Срочно — это +40% к цене и сдвиг очереди. Возможно почти всегда. Слот в Q3 пока есть.",
        "faq.q6": "Как с NDA и кодом?",
        "faq.a6": "Стандартное NDA на этапе брифа. Весь код — ваш с первого коммита. Доступ к репозиторию у вас постоянный.",

        "contact.num":   "07 / Бриф",
        "contact.title": "Идея → продакшен. 30 дней.",
        "contact.lead":  "Если задача решает реальную проблему — мы её возьмём. Если нет — скажем прямо. Один разговор и оценка за 48 часов.",
        "contact.cta":   "Запустить проект",

        "footer.studio":  "BlackStack Studio",
        "footer.tag":     "Цифровая студия · est. 2024",
        "footer.col1":    "Что мы делаем",
        "footer.col1.1":  "Веб-продукты",
        "footer.col1.2":  "Автоматизация",
        "footer.col1.3":  "Интерфейсы",
        "footer.col1.4":  "Кастомные системы",
        "footer.col2":    "Студия",
        "footer.col2.1":  "Манифест",
        "footer.col2.2":  "Процесс",
        "footer.col2.3":  "Кейсы",
        "footer.col2.4":  "Операторы",
        "footer.col3":    "Связь",
        "footer.col3.1":  "Telegram",
        "footer.col3.2":  "Email",
        "footer.col3.3":  "GitHub",
        "footer.col3.4":  "Запустить проект",
        "footer.col4":    "Юридическое",
        "footer.col4.1":  "Privacy",
        "footer.col4.2":  "Terms",
        "footer.col4.3":  "NDA по запросу",
        "footer.copy":    "© 2024–2026 BlackStack Studio · Все права защищены",
        "footer.loc":     "Async · Worldwide",
        "footer.timelbl": "Ваше время",
    },

    en: {
        "loader.label": "INITIALIZING BLACKSTACK SYSTEM",

        "nav.expertise": "Practice",
        "nav.projects":  "Cases",
        "nav.team":      "Operators",
        "nav.contact":   "Brief",
        "nav.cta":       "Launch a project",

        "hero.typed": "Digital products built to scale — while the competition is still writing the brief.",
        "hero.meta1": "Operators",
        "hero.meta2": "Launches",
        "hero.meta3": "Since",
        "hero.scroll": "Scroll",

        "now.label": "NOW · STUDIO AT WORK",
        "now.c1": "Active sprints",
        "now.c2": "In discovery",
        "now.c3": "On retainer",
        "now.c4": "Operators online",
        "now.c5": "Reply to brief",
        "now.c6": "Q3 slots left",

        "clients.label": "In good company",
        "clients.title": "Selected work & partners",
        "clients.note": "Direct builds and white-label · NDA work on request",

        "manifesto.num": "— / Manifesto",
        "manifesto.quote": "Fewer meetings. More production.",
        "manifesto.lead": "You don't need 40-page briefs, weekly check-ins or decks selling you something you already bought. You need a working product. Decisions in an hour. Production in 30 days. Repo access from the first commit. No middlemen.",
        "manifesto.sign": "BlackStack Studio · Manifesto",

        "expertise.num":   "01 / Practice",
        "expertise.title": "What we build",
        "expertise.lead":  "We build products that earn while you sleep — the bot closing deals, the dashboard reconciling positions, the queue draining itself. Control. Speed. Scale.",

        "card1.title": "Web Products",
        "card1.text":  "React, Next.js, Node. Not websites — conversion machines: sub-1s LCP, a measurable funnel, production in 4–8 weeks. Every pixel earns its keep.",
        "card2.title": "Automation",
        "card2.text":  "Python, aiogram, PostgreSQL. Bots and pipelines that replace a five-person ops team and never take vacation. ROI measured in hours and headcount.",
        "card3.title": "Interfaces",
        "card3.text":  "Figma to code. Design systems that scale with the product instead of falling apart on the third iteration. Emotion first, metric second — both hit the KPI.",
        "card3.tag2":  "Motion",
        "card3.tag3":  "Systems",
        "card4.title": "Custom",
        "card4.text":  "When nothing off-the-shelf fits, we build it. Architectures under real load, integrations, 30-day MVPs. Impossible is just more expensive.",
        "card4.tag1":  "Architecture",

        "projects.num":   "02 / Cases",
        "projects.title": "Recent launches",
        "projects.lead":  "Not a portfolio — a scoreboard. Every project earns money for the client or saves it in hours. Proof inside.",
        "projects.view":  "Open case →",
        "proj1.tag":  "Fintech · Dashboard",
        "proj1.desc": "Realtime trading terminal: sub-80ms ticks, a command palette, an in-house charting engine. Moved the client off TradingView onto our stack in a single quarter.",
        "proj2.tag":  "SaaS · Automation",
        "proj2.desc": "An internal OS that retired 14 SaaS subscriptions. Paid for itself in two months. A 22-person team now ships like 40.",
        "proj3.tag":  "Brand · Web",
        "proj3.desc": "Identity and microsite for an architecture practice. Six months in: three design-directory features and a six-month client waitlist.",
        "proj4.tag":  "Bot · Telegram",
        "proj4.desc": "Multi-tenant bot: 40k active users, stateful flows, billing, admin panel. Maintenance: one engineer at quarter-time.",

        "stats.num":   "02.5 / By the numbers",
        "stats.title": "Compound interest in action",
        "stats.lead":  "Updated monthly. No rounding to billions, no fairy tales.",
        "stats.c1":    "Projects in production",
        "stats.c2":    "Countries reached",
        "stats.c3":    "Releases without rollback",
        "stats.c4":    "Average page load",
        "stats.c5":    "Users on client products",
        "stats.c6":    "Days of free post-launch support",

        "process.num":   "03 / Process",
        "process.title": "How we work",
        "process.lead":  "Three phases. No surprises. No two-week silences. No 'we'll get back to you'.",
        "process.s1.phase": "Discover",
        "process.s1.title": "We listen and cut the noise",
        "process.s1.text":  "1–2 weeks. One call, a technical audit, a prototype on paper. We walk away if it's not our problem to solve.",
        "process.s1.time":  "1–2 weeks",
        "process.s2.phase": "Build",
        "process.s2.title": "We ship in the open",
        "process.s2.text":  "4–10 weeks. Weekly releases, a shared Telegram channel, repo access from day one.",
        "process.s2.time":  "4–10 weeks",
        "process.s3.phase": "Compound",
        "process.s3.title": "We stay and grow it",
        "process.s3.text":  "After launch we don't disappear. Metrics, iterations, growth. Process > Event — we're here for the long run.",
        "process.s3.time":  "60+ days",
        "process.sign":  "Ship-and-forget is event logic. We're not that.",

        "team.num":   "04 / Operators",
        "team.title": "Four. No middlemen.",
        "team.lead":  "No account managers, no buffer layer. You message the people writing the code. Decisions land in an hour, not after a week of calls.",
        "m1.name": "K. Vorobyev", "m1.role": "Backend · Automation",
        "m2.name": "A. Lerner",   "m2.role": "Backend · Infrastructure",
        "m3.name": "M. Sokolova", "m3.role": "Frontend · Interface",
        "m4.name": "D. Reizen",   "m4.role": "Design · Art Direction",

        "engagement.num":   "05 / Engagement",
        "engagement.title": "How to work with us",
        "engagement.lead":  "No hourly rates. Hours are slowlane. We get paid for results and ship by deliverables.",
        "engagement.e1.title": "Fixed Sprint",
        "engagement.e1.price": "from €18,000",
        "engagement.e1.text":  "30 days, fixed scope, fixed price. For MVPs and product bets.",
        "engagement.e2.title": "Retainer",
        "engagement.e2.price": "from €12,000 / mo",
        "engagement.e2.text":  "Monthly contract. From one operator to four. For teams building, not patching.",
        "engagement.e3.title": "Equity / Co-build",
        "engagement.e3.price": "stake + lower cash",
        "engagement.e3.text":  "We take a stake for the work. For rare projects where Scale is obvious.",
        "engagement.e4.title": "Advisory",
        "engagement.e4.price": "€280 / hour",
        "engagement.e4.text":  "Architecture audit, code review, hiring help. For founders who already have a team.",

        "faq.num":   "06 / FAQ",
        "faq.title": "Common fears, straight answers",
        "faq.lead":  "The questions you'd ask three minutes into the call. Answered upfront.",
        "faq.q1": "How much does it cost?",
        "faq.a1": "Sprint — from €18K fixed. Retainer — from €12K/month. Exact number after a 30-minute brief. No 'sign the NDA first' theatre.",
        "faq.q2": "How fast can you ship?",
        "faq.a2": "30 days to production for an MVP. 4–10 weeks for medium-complexity products. Release date is locked on the first call.",
        "faq.q3": "What if I don't like the result?",
        "faq.a3": "Weekly releases — you see it as it happens. Don't like it — we course-correct that week, not in a month. No refunds, only iteration.",
        "faq.q4": "Four people — can you handle a big project?",
        "faq.a4": "Yes. Each of us owns a zone end-to-end, no handoff through a manager. One senior beats five juniors and three PMs. If we can't carry it, we say so before the brief, not on week two.",
        "faq.q5": "Do you do rush jobs?",
        "faq.a5": "Rush means +40% and we move the queue. Almost always doable. Q3 slot is still open.",
        "faq.q6": "NDA and code ownership?",
        "faq.a6": "Standard NDA at brief stage. All code is yours from the first commit. You have permanent repo access.",

        "contact.num":   "07 / Brief",
        "contact.title": "Idea → production. 30 days.",
        "contact.lead":  "If the problem is real and the market is there, we'll take it. If it isn't, we'll say so. One call, an estimate in 48 hours.",
        "contact.cta":   "Launch a project",

        "footer.studio":  "BlackStack Studio",
        "footer.tag":     "Digital studio · est. 2024",
        "footer.col1":    "What we do",
        "footer.col1.1":  "Web Products",
        "footer.col1.2":  "Automation",
        "footer.col1.3":  "Interfaces",
        "footer.col1.4":  "Custom Systems",
        "footer.col2":    "Studio",
        "footer.col2.1":  "Manifesto",
        "footer.col2.2":  "Process",
        "footer.col2.3":  "Cases",
        "footer.col2.4":  "Operators",
        "footer.col3":    "Contact",
        "footer.col3.1":  "Telegram",
        "footer.col3.2":  "Email",
        "footer.col3.3":  "GitHub",
        "footer.col3.4":  "Launch a project",
        "footer.col4":    "Legal",
        "footer.col4.1":  "Privacy",
        "footer.col4.2":  "Terms",
        "footer.col4.3":  "NDA on request",
        "footer.copy":    "© 2024–2026 BlackStack Studio · All rights reserved",
        "footer.loc":     "Async · Worldwide",
        "footer.timelbl": "Your time",
    },

    uk: {
        "loader.label": "ІНІЦІАЛІЗАЦІЯ СИСТЕМИ BLACKSTACK",

        "nav.expertise": "Практика",
        "nav.projects":  "Кейси",
        "nav.team":      "Оператори",
        "nav.contact":   "Бриф",
        "nav.cta":       "Запустити проєкт",

        "hero.typed": "Цифрові продукти, побудовані під масштаб — поки конкуренти пишуть ТЗ.",
        "hero.meta1": "Операторів",
        "hero.meta2": "Запусків",
        "hero.meta3": "На ринку з",
        "hero.scroll": "Далі",

        "now.label": "NOW · СТУДІЯ У РОБОТІ",
        "now.c1": "Активних спринтів",
        "now.c2": "У discovery",
        "now.c3": "На підтримці",
        "now.c4": "Операторів онлайн",
        "now.c5": "Відповідь на бриф",
        "now.c6": "Слотів у Q3",

        "clients.label": "У хорошій компанії",
        "clients.title": "Кейси та партнери",
        "clients.note": "Прямі запуски і white-label · NDA-проєкти на запит",

        "manifesto.num": "— / Маніфест",
        "manifesto.quote": "Менше зустрічей. Більше продакшну.",
        "manifesto.lead": "Вам не потрібні 40-сторінкові брифи, weekly check-in'и та презентації, що продають вам те, що ви вже купили. Вам потрібен робочий продукт. Рішення — за годину. Реліз — за 30 днів. Доступ до коду — з першого коміту. Без прошарків.",
        "manifesto.sign": "BlackStack Studio · Маніфест",

        "expertise.num":   "01 / Практика",
        "expertise.title": "Що ми будуємо",
        "expertise.lead":  "Ми робимо продукти, що приносять гроші уві сні: бот закриває угоди, дешборд рахує позицію, черга чиститься сама — поки ви спите. Контроль. Швидкість. Масштаб.",

        "card1.title": "Веб-продукти",
        "card1.text":  "React, Next.js, Node. Не сайти — машини конверсії: LCP менше секунди, вимірювана воронка, продакшн за 4–8 тижнів. Кожен піксель працює на дохід.",
        "card2.title": "Автоматизація",
        "card2.text":  "Python, aiogram, PostgreSQL. Боти й пайплайни, що замінюють відділ з п'яти людей і не йдуть у відпустку. Економію рахуємо в годинах і зарплатах.",
        "card3.title": "Інтерфейси",
        "card3.text":  "Figma + код. Дизайн-системи, що масштабуються разом з продуктом, а не розвалюються на третій ітерації. Спершу емоція, потім метрика — обидві потрапляють у KPI.",
        "card3.tag2":  "Motion",
        "card3.tag3":  "Системи",
        "card4.title": "Кастом",
        "card4.text":  "Коли готового немає — збираємо самі. Архітектура під навантаження, інтеграції, MVP за 30 днів. Неможливе — це просто дорожче.",
        "card4.tag1":  "Архітектура",

        "projects.num":   "02 / Кейси",
        "projects.title": "Свіжі запуски",
        "projects.lead":  "Не портфоліо — рахунок. Кожен проєкт приносить замовнику гроші або економить години. Докази всередині.",
        "projects.view":  "Відкрити кейс →",
        "proj1.tag":  "Фінтех · Дешборд",
        "proj1.desc": "Торговий термінал реального часу: тики менше 80 мс, командна палітра, власний рушій графіків. Замовник перейшов з TradingView на наш стек за квартал.",
        "proj2.tag":  "SaaS · Автоматизація",
        "proj2.desc": "Внутрішня ОС, що замінила 14 SaaS-підписок. Окупилась за два місяці. Команда з 22 людей працює як 40.",
        "proj3.tag":  "Бренд · Веб",
        "proj3.desc": "Айдентика й мікросайт для архітектурного бюро. За пів року — три потрапляння в добірки та черга клієнтів на пів року вперед.",
        "proj4.tag":  "Бот · Telegram",
        "proj4.desc": "Мультитенантний бот: 40 000 активних користувачів, stateful-флоу, білінг, адмінка. Підтримка — один інженер на чверть ставки.",

        "stats.num":   "02.5 / У цифрах",
        "stats.title": "Складний відсоток у дії",
        "stats.lead":  "Цифри оновлюються раз на місяць. Без округлень до мільярдів і без казок.",
        "stats.c1":    "Проєктів у продакшні",
        "stats.c2":    "Країн аудиторії",
        "stats.c3":    "Релізів без відкату",
        "stats.c4":    "Середня швидкість сайтів",
        "stats.c5":    "Користувачів у клієнтів",
        "stats.c6":    "Днів підтримки після релізу",

        "process.num":   "03 / Процес",
        "process.title": "Як ми працюємо",
        "process.lead":  "Три фази. Без сюрпризів. Без мовчання на два тижні. Без «ми вам напишемо».",
        "process.s1.phase": "Discover",
        "process.s1.title": "Слухаємо й ріжемо зайве",
        "process.s1.text":  "1–2 тижні. Один дзвінок, технічний аудит, прототип рішення на папері. Йдемо геть, якщо задача не наша.",
        "process.s1.time":  "1–2 тижні",
        "process.s2.phase": "Build",
        "process.s2.title": "Будуємо відкрито",
        "process.s2.text":  "4–10 тижнів. Релізи що 7 днів, спільний канал у Telegram, доступ до репозиторію з першого дня.",
        "process.s2.time":  "4–10 тижнів",
        "process.s3.phase": "Compound",
        "process.s3.title": "Лишаємось і нарощуємо",
        "process.s3.text":  "Після релізу ми не зникаємо. Метрики, ітерації, зростання. Process > Event — ми тут надовго.",
        "process.s3.time":  "60+ днів",
        "process.sign":  "«Здав і забув» — це event-логіка. Ми так не вміємо.",

        "team.num":   "04 / Оператори",
        "team.title": "Четверо. Без посередників.",
        "team.lead":  "Ні менеджерів, ні прошарку. Ви пишете тим, хто пише код. Рішення — за годину, а не за тиждень дзвінків.",
        "m1.name": "К. Воробйов", "m1.role": "Бекенд · Автоматизація",
        "m2.name": "А. Лернер",   "m2.role": "Бекенд · Інфраструктура",
        "m3.name": "М. Соколова", "m3.role": "Фронтенд · Інтерфейс",
        "m4.name": "Д. Рейзен",   "m4.role": "Дизайн · Арт-дирекшн",

        "engagement.num":   "05 / Модель роботи",
        "engagement.title": "Як з нами працювати",
        "engagement.lead":  "Без погодинних ставок. Години — це slowlane. Платимо за результат, рахуємо по deliverables.",
        "engagement.e1.title": "Fixed Sprint",
        "engagement.e1.price": "від €18 000",
        "engagement.e1.text":  "30 днів, фіксований scope, фіксована ціна. Для MVP і продуктових ставок.",
        "engagement.e2.title": "Retainer",
        "engagement.e2.price": "від €12 000 / міс",
        "engagement.e2.text":  "Місячний контракт. Команда від одного оператора до чотирьох. Для тих, хто будує, а не латає.",
        "engagement.e3.title": "Equity / Co-build",
        "engagement.e3.price": "частка + нижчий кеш",
        "engagement.e3.text":  "Беремо за роботу частку. Для рідкісних проєктів, де Scale очевидний.",
        "engagement.e4.title": "Advisory",
        "engagement.e4.price": "€280 / година",
        "engagement.e4.text":  "Архітектурний аудит, code review, наймовий консалтинг. Для founders, у яких вже є команда.",

        "faq.num":   "06 / FAQ",
        "faq.title": "Головні страхи й прямі відповіді",
        "faq.lead":  "Те, про що ви запитаєте на третій хвилині дзвінка. Відповідаємо заздалегідь.",
        "faq.q1": "Скільки це коштує?",
        "faq.a1": "Sprint — від €18K фікс. Retainer — від €12K/міс. Точна цифра — після 30-хвилинного брифу. Без театру «спочатку підпишемо NDA».",
        "faq.q2": "За скільки ви робите?",
        "faq.a2": "Від 30 днів до продакшну для MVP. 4–10 тижнів для продуктів середньої складності. Дата релізу фіксується на першому дзвінку.",
        "faq.q3": "А якщо результат не сподобається?",
        "faq.a3": "Релізи кожні 7 днів — ви бачите все на ходу. Не подобається — корегуємо того ж тижня, а не через місяць. Повернень не передбачаємо — лише ітерація.",
        "faq.q4": "Вас всього четверо — потягнете великий проєкт?",
        "faq.a4": "Так. Кожен закриває свою зону end-to-end, без передач через менеджера. Один senior > п'ять джунів і трьох менеджерів. Якщо не тягнемо — кажемо до брифу, не на другому тижні.",
        "faq.q5": "Беретеся терміново?",
        "faq.a5": "Терміново — це +40% до ціни й зрушення черги. Можливо майже завжди. Слот у Q3 ще є.",
        "faq.q6": "Як з NDA та кодом?",
        "faq.a6": "Стандартне NDA на етапі брифу. Весь код — ваш з першого коміту. Доступ до репозиторію постійний.",

        "contact.num":   "07 / Бриф",
        "contact.title": "Ідея → продакшн. 30 днів.",
        "contact.lead":  "Якщо задача розв'язує реальну проблему — ми її візьмемо. Якщо ні — скажемо прямо. Одна розмова й оцінка за 48 годин.",
        "contact.cta":   "Запустити проєкт",

        "footer.studio":  "BlackStack Studio",
        "footer.tag":     "Цифрова студія · est. 2024",
        "footer.col1":    "Що ми робимо",
        "footer.col1.1":  "Веб-продукти",
        "footer.col1.2":  "Автоматизація",
        "footer.col1.3":  "Інтерфейси",
        "footer.col1.4":  "Кастомні системи",
        "footer.col2":    "Студія",
        "footer.col2.1":  "Маніфест",
        "footer.col2.2":  "Процес",
        "footer.col2.3":  "Кейси",
        "footer.col2.4":  "Оператори",
        "footer.col3":    "Зв'язок",
        "footer.col3.1":  "Telegram",
        "footer.col3.2":  "Email",
        "footer.col3.3":  "GitHub",
        "footer.col3.4":  "Запустити проєкт",
        "footer.col4":    "Юридичне",
        "footer.col4.1":  "Privacy",
        "footer.col4.2":  "Terms",
        "footer.col4.3":  "NDA на запит",
        "footer.copy":    "© 2024–2026 BlackStack Studio · Всі права захищені",
        "footer.loc":     "Async · Worldwide",
        "footer.timelbl": "Ваш час",
    },
};

/* =========================================================
   СОСТОЯНИЕ И УТИЛИТЫ
   ========================================================= */
const STORAGE_KEY = "bs.lang";
let currentLang = localStorage.getItem(STORAGE_KEY) || "ru";
if (!I18N[currentLang]) currentLang = "ru";

function t(key) {
    return (I18N[currentLang] && I18N[currentLang][key]) || I18N.ru[key] || key;
}

function applyTranslations() {
    document.documentElement.lang = currentLang;

    // обычные текстовые ключи + опциональный атрибут (data-i18n-attr)
    document.querySelectorAll("[data-i18n]").forEach((el) => {
        const key = el.getAttribute("data-i18n");
        const attr = el.getAttribute("data-i18n-attr");
        const value = t(key);
        if (attr) el.setAttribute(attr, value);
        // если у элемента есть видимый текст — обновляем и его (даже если задан data-i18n-attr,
        // т.к. glitch-эффект использует и data-text, и textContent одновременно).
        el.textContent = value;
    });

    // пере-сплит уже отрендеренных split-заголовков
    resplit();

    // показать сплитнутые заголовки, попадающие в viewport (после перерендера)
    document.querySelectorAll("[data-split]").forEach((el) => {
        const r = el.getBoundingClientRect();
        if (r.top < window.innerHeight && r.bottom > 0) {
            requestAnimationFrame(() => el.classList.add("is-in"));
        }
    });

    updateLangPill();
    restartTypewriter();
}

/* =========================================================
   ПЕРЕКЛЮЧАТЕЛЬ ЯЗЫКА
   ========================================================= */
function initLangSwitch() {
    const wrap = document.getElementById("langSwitch");
    if (!wrap) return;

    wrap.querySelectorAll("[data-lang]").forEach((btn) => {
        btn.addEventListener("click", () => {
            const lang = btn.dataset.lang;
            if (!I18N[lang] || lang === currentLang) return;
            currentLang = lang;
            localStorage.setItem(STORAGE_KEY, lang);

            wrap.querySelectorAll("[data-lang]").forEach((b) =>
                b.classList.toggle("is-active", b.dataset.lang === lang)
            );

            applyTranslations();
        });
    });

    // выставить активную кнопку в соответствии с сохранённым языком
    wrap.querySelectorAll("[data-lang]").forEach((b) =>
        b.classList.toggle("is-active", b.dataset.lang === currentLang)
    );
}

function updateLangPill() {
    const wrap = document.getElementById("langSwitch");
    const pill = document.getElementById("langPill");
    if (!wrap || !pill) return;
    const active = wrap.querySelector(".lang-switch__btn.is-active");
    if (!active) return;
    const rect = active.getBoundingClientRect();
    const parentRect = wrap.getBoundingClientRect();
    pill.style.width = rect.width + "px";
    pill.style.transform = `translateX(${rect.left - parentRect.left - 4}px)`;
}

/* =========================================================
   ЛОАДЕР
   ========================================================= */
function runLoader() {
    const loader = document.getElementById("loader");
    const fill = document.getElementById("loaderBarFill");
    const pct = document.getElementById("loaderPercent");
    if (!loader) return Promise.resolve();

    return new Promise((resolve) => {
        let p = 0;
        const start = performance.now();
        const minDuration = 1500;

        function step(now) {
            const elapsed = now - start;
            const target = Math.min(100, (elapsed / minDuration) * 100);
            p += (target - p) * 0.18;
            const display = Math.min(100, Math.round(p));
            if (fill) fill.style.width = display + "%";
            if (pct) pct.textContent = display;
            if (display < 100) {
                requestAnimationFrame(step);
            } else {
                setTimeout(() => {
                    loader.classList.add("is-done");
                    document.body.classList.add("is-loaded");
                    resolve();
                }, 280);
            }
        }
        requestAnimationFrame(step);
    });
}

/* =========================================================
   ПЕЧАТНАЯ МАШИНКА
   ========================================================= */
let typewriterTimer = null;

function restartTypewriter() {
    const el = document.getElementById("typewriter");
    if (!el) return;
    clearTimeout(typewriterTimer);
    el.textContent = "";

    const text = t("hero.typed");
    let i = 0;
    function tick() {
        if (i <= text.length) {
            el.textContent = text.slice(0, i++);
            typewriterTimer = setTimeout(tick, 32 + Math.random() * 30);
        }
    }
    tick();
}

/* =========================================================
   SPLIT TEXT (побуквенный reveal)
   ========================================================= */
function splitText() {
    document.querySelectorAll("[data-split]").forEach((el) => {
        if (el.dataset.splitDone) return;
        const text = el.textContent;
        el.textContent = "";
        // оборачиваем каждую букву в .char внутри inline-block span слова
        const words = text.split(" ");
        words.forEach((word, wi) => {
            const wordSpan = document.createElement("span");
            wordSpan.style.display = "inline-block";
            wordSpan.style.overflow = "hidden";
            wordSpan.style.lineHeight = "1.05";
            [...word].forEach((ch, ci) => {
                const span = document.createElement("span");
                span.className = "char";
                span.style.transitionDelay = (wi * 0.05 + ci * 0.022) + "s";
                span.textContent = ch;
                wordSpan.appendChild(span);
            });
            el.appendChild(wordSpan);
            if (wi < words.length - 1) el.appendChild(document.createTextNode(" "));
        });
        el.dataset.splitDone = "1";
    });
}

// при смене языка нужно пере-сплитать заголовки
function resplit() {
    document.querySelectorAll("[data-split]").forEach((el) => {
        el.dataset.splitDone = "";
        el.classList.remove("is-in");
    });
    splitText();
}

/* =========================================================
   SCROLL REVEAL (IntersectionObserver)
   ========================================================= */
function observeReveal() {
    const els = document.querySelectorAll("[data-reveal], [data-split]");
    const io = new IntersectionObserver(
        (entries) => {
            entries.forEach((e) => {
                if (e.isIntersecting) {
                    e.target.classList.add("is-in");
                    io.unobserve(e.target);
                }
            });
        },
        { threshold: 0.15, rootMargin: "0px 0px -60px 0px" }
    );
    els.forEach((el) => io.observe(el));
}

/* =========================================================
   NAV: скролл-состояние
   ========================================================= */
function navScroll() {
    const nav = document.getElementById("nav");
    if (!nav) return;
    let last = -1;
    window.addEventListener("scroll", () => {
        const y = window.scrollY;
        const scrolled = y > 40;
        if (scrolled !== last) {
            nav.classList.toggle("is-scrolled", scrolled);
            last = scrolled;
        }
    });
}

/* =========================================================
   КАРТОЧКИ: 3D-тилт + glow follow
   ========================================================= */
function tilt() {
    document.querySelectorAll("[data-tilt]").forEach((el) => {
        let raf = null;
        el.addEventListener("mousemove", (e) => {
            const rect = el.getBoundingClientRect();
            const x = (e.clientX - rect.left) / rect.width;
            const y = (e.clientY - rect.top) / rect.height;
            const rx = (0.5 - y) * 8;
            const ry = (x - 0.5) * 10;
            if (raf) cancelAnimationFrame(raf);
            raf = requestAnimationFrame(() => {
                el.style.transform = `perspective(900px) rotateX(${rx}deg) rotateY(${ry}deg) translateZ(0)`;
                el.style.setProperty("--mx", (x * 100) + "%");
                el.style.setProperty("--my", (y * 100) + "%");
            });
        });
        el.addEventListener("mouseleave", () => {
            el.style.transform = "perspective(900px) rotateX(0) rotateY(0)";
        });
    });
}

/* =========================================================
   MAGNETIC BUTTONS
   ========================================================= */
function magnetic() {
    document.querySelectorAll(".magnetic").forEach((el) => {
        const strength = 0.35;
        const radius = 120;
        let raf = null;

        function onMove(e) {
            const rect = el.getBoundingClientRect();
            const cx = rect.left + rect.width / 2;
            const cy = rect.top + rect.height / 2;
            const dx = e.clientX - cx;
            const dy = e.clientY - cy;
            const dist = Math.sqrt(dx * dx + dy * dy);
            if (dist > radius) {
                el.style.transform = "";
                return;
            }
            const f = (1 - dist / radius) * strength;
            if (raf) cancelAnimationFrame(raf);
            raf = requestAnimationFrame(() => {
                el.style.transform = `translate(${dx * f}px, ${dy * f}px)`;
            });
        }

        function reset() {
            el.style.transform = "";
        }

        window.addEventListener("mousemove", onMove);
        el.addEventListener("mouseleave", reset);
    });
}

/* =========================================================
   ПАРАЛЛАКС МАРКИ ПО СКРОЛЛУ
   ========================================================= */
function parallaxMark() {
    const mark = document.querySelector(".hero__mark");
    const title = document.querySelector(".hero__title");
    const sub = document.querySelector(".hero__sub");
    if (!mark) return;

    window.addEventListener("scroll", () => {
        const y = window.scrollY;
        const h = window.innerHeight;
        const p = Math.min(y / h, 1);
        mark.style.transform = `translateY(${p * -80}px) scale(${1 - p * 0.15})`;
        if (title) title.style.transform = `translateY(${p * -40}px)`;
        if (sub)   sub.style.transform   = `translateY(${p * -20}px)`;
    }, { passive: true });
}

/* =========================================================
   ЧАСЫ В ФУТЕРЕ — локальное время посетителя + город из IANA tz
   ========================================================= */
function startClock() {
    const el = document.getElementById("footerTime");
    const cityEl = document.getElementById("footerCity");
    if (!el) return;

    // IANA-зона вида "Europe/Moscow" → "Moscow"
    let tz = "UTC";
    let city = "Local";
    try {
        tz = Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC";
        const parts = tz.split("/");
        city = (parts[parts.length - 1] || "Local").replace(/_/g, " ");
    } catch (e) { /* старые браузеры — игнор */ }

    if (cityEl) cityEl.textContent = `${city} · ${tz}`;

    function pad(n) { return String(n).padStart(2, "0"); }
    function offsetStr(d) {
        const off = -d.getTimezoneOffset();
        const sign = off >= 0 ? "+" : "−";
        const h = Math.floor(Math.abs(off) / 60);
        const m = Math.abs(off) % 60;
        return `UTC${sign}${pad(h)}${m ? ":" + pad(m) : ""}`;
    }
    function tick() {
        const d = new Date();
        el.textContent = `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())} · ${offsetStr(d)}`;
    }
    tick();
    setInterval(tick, 1000);
}

/* =========================================================
   СЧЁТЧИКИ МЕТРИК (count-up на скролле)
   ========================================================= */
function initStats() {
    const stats = document.querySelectorAll("[data-count]");
    if (!stats.length) return;

    const easeOut = (t) => 1 - Math.pow(1 - t, 3);
    const animate = (el) => {
        const target   = parseFloat(el.dataset.count);
        const decimals = parseInt(el.dataset.decimals || "0", 10);
        const prefix   = el.dataset.prefix || "";
        const suffix   = el.dataset.suffix || "";
        const duration = 1800;
        const start    = performance.now();

        function step(now) {
            const p = Math.min(1, (now - start) / duration);
            const v = (target * easeOut(p)).toFixed(decimals);
            el.textContent = prefix + v + suffix;
            if (p < 1) requestAnimationFrame(step);
        }
        requestAnimationFrame(step);
    };

    const io = new IntersectionObserver((entries) => {
        entries.forEach((e) => {
            if (e.isIntersecting) {
                animate(e.target);
                io.unobserve(e.target);
            }
        });
    }, { threshold: 0.35 });

    stats.forEach((s) => io.observe(s));
}

/* =========================================================
   ИНИЦИАЛИЗАЦИЯ
   ========================================================= */
document.addEventListener("DOMContentLoaded", () => {
    initLangSwitch();
    applyTranslations();
    splitText();

    navScroll();
    parallaxMark();
    tilt();
    magnetic();
    startClock();
    initStats();

    runLoader().then(() => {
        observeReveal();
        // короткий старт печатной машинки чтобы успел отработать reveal
        setTimeout(restartTypewriter, 300);
    });
});

// обновлять позицию пилюли переключателя при ресайзе
window.addEventListener("resize", updateLangPill);
