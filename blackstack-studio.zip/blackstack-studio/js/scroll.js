/* =========================================================
   BlackStack — Smooth scroll (Lenis) + GSAP ScrollTrigger.
   Подключается ПОСЛЕ main.js. Дополняет существующие анимации,
   а не заменяет их.
   ========================================================= */

(function () {
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const hasGSAP = typeof window.gsap !== "undefined";
    const hasLenis = typeof window.Lenis !== "undefined";
    const hasST = hasGSAP && typeof window.ScrollTrigger !== "undefined";

    /* ---------- Lenis smooth scroll ---------- */
    let lenis = null;
    if (hasLenis && !reduced) {
        try {
            lenis = new Lenis({
                duration: 1.15,
                easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
                smoothWheel: true,
                smoothTouch: false, // на тачах оставляем нативный
                lerp: 0.085,
                wheelMultiplier: 1.0
            });
            window.__lenis = lenis;
        } catch (e) { /* старый браузер — забиваем */ }
    }

    /* ---------- GSAP register + ticker bridge ---------- */
    if (hasST) {
        try { gsap.registerPlugin(ScrollTrigger); } catch (e) {}
    }
    if (hasGSAP && lenis) {
        lenis.on("scroll", () => { if (hasST) ScrollTrigger.update(); });
        gsap.ticker.add((time) => { lenis.raf(time * 1000); });
        gsap.ticker.lagSmoothing(0);
    } else if (lenis) {
        // если GSAP не подгрузился — крутим Lenis сами
        function raf(t) { lenis.raf(t); requestAnimationFrame(raf); }
        requestAnimationFrame(raf);
    }

    /* ---------- Скролл-анимации (только если GSAP+ST доступны) ---------- */
    if (!hasST) return;

    // 1. Section titles — мягкий blur-in + lift на входе в viewport
    document.querySelectorAll("[data-split]").forEach((el) => {
        gsap.fromTo(el,
            { yPercent: 8, opacity: 0, filter: "blur(8px)" },
            {
                yPercent: 0, opacity: 1, filter: "blur(0px)",
                duration: 1.0, ease: "expo.out",
                scrollTrigger: {
                    trigger: el,
                    start: "top 85%",
                    toggleActions: "play none none reverse"
                }
            }
        );
    });

    // 2. Карточки экспертизы — stagger
    if (document.querySelector(".cards")) {
        gsap.from(".cards .card", {
            y: 80, opacity: 0, rotateX: 12,
            transformPerspective: 1200, transformOrigin: "50% 100%",
            stagger: 0.08, duration: 0.9, ease: "power3.out",
            scrollTrigger: { trigger: ".cards", start: "top 75%" }
        });
    }

    // 3. Проекты — reveal с clip-path
    document.querySelectorAll(".project__visual").forEach((v) => {
        gsap.fromTo(v,
            { clipPath: "inset(0 0 100% 0)", scale: 1.1, filter: "blur(18px)" },
            {
                clipPath: "inset(0 0 0% 0)", scale: 1, filter: "blur(0px)",
                duration: 1.3, ease: "power4.out",
                scrollTrigger: { trigger: v, start: "top 78%" }
            }
        );
    });

    // 4. Manifesto-цитата — большой blur-in + slow float
    const mq = document.querySelector(".manifesto__quote");
    if (mq) {
        gsap.fromTo(mq,
            { opacity: 0, filter: "blur(30px)", scale: 0.95 },
            {
                opacity: 1, filter: "blur(0px)", scale: 1,
                duration: 1.6, ease: "expo.out",
                scrollTrigger: { trigger: mq, start: "top 80%" }
            }
        );
    }

    // 5. Stats grid — каждая ячейка по очереди
    if (document.querySelector(".stats__grid")) {
        gsap.from(".stats__grid .stat", {
            y: 60, opacity: 0, stagger: 0.07, duration: 0.9, ease: "power3.out",
            scrollTrigger: { trigger: ".stats__grid", start: "top 80%" }
        });
    }

    // 6. Process steps — slide-in с разных сторон
    document.querySelectorAll(".process__step").forEach((step, i) => {
        gsap.from(step, {
            y: 50, opacity: 0,
            duration: 0.9, ease: "power3.out",
            delay: i * 0.12,
            scrollTrigger: { trigger: ".process__track", start: "top 75%" }
        });
    });

    // 7. Team members — stagger с лёгким glitch при появлении
    document.querySelectorAll(".member").forEach((m, i) => {
        gsap.from(m, {
            x: -30, opacity: 0,
            duration: 0.8, ease: "power3.out",
            delay: i * 0.08,
            scrollTrigger: { trigger: ".team__grid", start: "top 80%" }
        });
    });

    // 8. Nav — scroll-state
    ScrollTrigger.create({
        start: 40, end: "max",
        toggleClass: { targets: "#nav", className: "is-scrolled" }
    });

    // 9. Параллакс марки в hero (плавно)
    const mark = document.querySelector(".hero__mark");
    if (mark) {
        gsap.to(mark, {
            yPercent: -30, scale: 0.85, opacity: 0.6,
            ease: "none",
            scrollTrigger: {
                trigger: ".hero",
                start: "top top",
                end: "bottom top",
                scrub: 0.8
            }
        });
    }

    // 10. Marquee velocity — ускоряется на скролле (если есть marquee-track)
    const mTrack = document.querySelector(".marquee__track");
    if (mTrack && lenis) {
        let velocityBoost = 0;
        lenis.on("scroll", ({ velocity }) => {
            velocityBoost = Math.min(Math.abs(velocity) * 0.0025, 0.6);
        });
        gsap.ticker.add(() => {
            velocityBoost *= 0.94;
            mTrack.style.animationDuration = (40 - velocityBoost * 30) + "s";
        });
    }
})();
